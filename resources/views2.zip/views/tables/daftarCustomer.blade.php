        @extends('layouts.app',['title'=>'Data Customer','content'=>'Data customer'])

        @section('content')

        <div class="col-12 col-md-12 col-lg-12">
            <div class="card">
                <div class="card-header col-12">
                    <h4 class="col-8">Data Customer</h4>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="myTable" class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Nama Customer</th>
                                    <th>Alamat Customer</th>
                                    <th>Nama Area</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($customer as $c)
                                <tr>
                                    <td>{{ $loop->iteration }}</td>
                                    <td>{{ $c->nama_customer }}</td>
                                    <td>{{ $c->alamat_customer }}</td>
                                    <td>{{ $c->area->nama_area ?? 'BELUM TERDAFTAR' }}</td>
                                    <td><a href="" class="btn btn-warning">EDIT</a></td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    <div>
                        <nav>
                            <ul class="float-left">
                                <p>Total customer : <strong>{{ $customer->total() }} Customer</strong></p>
                            </ul>
                            <ul class="pagination float-right">
                                {{ $customer->links() }}
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
        <script>
            function myFunction() {
                // Declare variables
                var input, filter, table, tr, td, i, txtValue;
                input = document.getElementById("myInput");
                filter = input.value.toUpperCase();
                table = document.getElementById("myTable");
                tr = table.getElementsByTagName("tr");

                // Loop through all table rows, and hide those who don't match the search query
                for (i = 0; i < tr.length; i++) {
                    td = tr[i].getElementsByTagName("td")[0];
                    if (td) {
                        txtValue = td.textContent || td.innerText;
                        if (txtValue.toUpperCase().indexOf(filter) > -1) {
                            tr[i].style.display = "";
                        } else {
                            tr[i].style.display = "none";
                        }
                    }
                }
            }

        </script>

        @endsection
